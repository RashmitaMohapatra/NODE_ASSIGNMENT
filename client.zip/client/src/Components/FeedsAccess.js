import React from 'react'

const FeedsAccess = () => {
  return (
    <>
        Feeds Access
    </>
  )
}

export default FeedsAccess